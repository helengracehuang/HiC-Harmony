require("bnbc") || stop("unable to load bnbc")
BiocGenerics:::testPackage("bnbc")
