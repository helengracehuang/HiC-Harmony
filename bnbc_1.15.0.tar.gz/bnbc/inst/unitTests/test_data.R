test_data <- function() {
    data(cgEx)
    checkTrue(validObject(cgEx))
}
